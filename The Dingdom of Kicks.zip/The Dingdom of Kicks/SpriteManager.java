import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class SpriteManager {
    private BufferedImage spriteSheet;
    private BufferedImage[] playerSprites;
    private final int spriteWidth = 48; 
    private final int spriteHeight = 48; 

    public SpriteManager(String path) {
        try {
            spriteSheet = ImageIO.read(getClass().getResourceAsStream(path));
        } catch (IOException e) {
            e.printStackTrace();
        }
        loadPlayerSprites();
    }

    private void loadPlayerSprites() {
        playerSprites = new BufferedImage[4];
        for (int i = 0; i < 4; i++) {
            playerSprites[i] = spriteSheet.getSubimage(i * spriteWidth, 0, spriteWidth, spriteHeight);
        }
    }

    public BufferedImage getPlayerSprite(int index) {
        return playerSprites[index];
    }
}
