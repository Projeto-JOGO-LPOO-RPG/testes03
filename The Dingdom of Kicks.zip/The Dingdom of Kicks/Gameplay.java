public class Gameplay {
    private Jogador jogador1;
    private Interacao interacao;
    private Combate combate;

    public Gameplay() {
        jogador1 = Jogador.escolherPersonagem("Nome do Jogador", 1, 0);
        jogador1.obterNome();

        interacao = new Interacao();
        combate = new Combate(jogador1);

        interacao.interagirNPC();
        combate.Combater();
    }

    public void runGameplay() {
        do {
            
        } while(true);
    }
}