public abstract class NPC extends Entidade {
    private String dialogo;

    public NPC(String nomeEntidade, int coordX, int coordY, int velocidade, int numSprite, String dialogo, boolean isVivo) {
        super(nomeEntidade, coordX, coordY, velocidade, numSprite, numSprite, numSprite, numSprite, numSprite, isVivo);
        this.dialogo = dialogo;
    }

    public static NPC escolherNPC(String nomeNPC, String dialogo) {

        int npcIndex = 1;

        switch (npcIndex) {
            case 1:
                return new Aldeao(nomeNPC, dialogo);
        
            default:
                System.out.println("Escolha inválida");
                return null;
        }
    }

    public String getDialogo() {
        return dialogo;
    }

    public void setDialogo(String dialogo) {
        this.dialogo = dialogo;
    }
}