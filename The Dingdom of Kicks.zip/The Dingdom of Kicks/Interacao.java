public class Interacao {
    private NPC Aldeao1;

    public Interacao() {
        Aldeao1 = NPC.escolherNPC("Nome do Aldeal", " ");
    }
    

    public void interagirNPC(){
        String dialogo = Aldeao1.getDialogo();
         System.out.println(dialogo);


    }
}
