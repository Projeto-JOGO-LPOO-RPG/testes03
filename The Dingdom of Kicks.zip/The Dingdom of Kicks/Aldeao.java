public class Aldeao extends NPC {
    public Aldeao(String nome, String dialogo) {
        super(nome, 0, 0, 3,
         0, "Bem vindo à Vila de Hard Hard Crock", true);

    }
}
