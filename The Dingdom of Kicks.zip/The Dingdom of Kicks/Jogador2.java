public class Jogador2 extends Entidade {
    GamePanel gp;
    KeyHandler keyH;

    public Jogador2(GamePanel gp, KeyHandler keyH, String nomeEntidade, int pontosVida, int pontosDefesa, int pontosAtaque, int pontosMagia, 
                    int coordX, int coordY, int velocidade, int numSprite, boolean isVivo) {
        super(nomeEntidade, pontosVida, pontosDefesa, pontosAtaque, pontosMagia, coordX, coordY, velocidade, numSprite, isVivo);
        this.gp = gp;
        this.keyH = keyH;
    }

    public void setDefaultValues(){

    x=100;
    y=100;
    speed=4;
    }

}

