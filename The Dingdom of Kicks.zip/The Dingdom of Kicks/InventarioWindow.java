import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

public class InventarioWindow extends JFrame {

    private Inventario inventario;
    private JList<Item> itemList;
    private DefaultListModel<Item> listModel;
    private JTextArea itemDescriptionArea;

    public InventarioWindow() {
        setTitle("Inventário");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        inventario = new Inventario();
        initUI();
    }

    private void initUI() {
        listModel = new DefaultListModel<>();
        itemList = new JList<>(listModel);
        itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        itemList.addListSelectionListener(e -> {
            Item selectedItem = itemList.getSelectedValue();
            if (selectedItem != null) {
                itemDescriptionArea.setText("Descrição: " + selectedItem.getDescricao() +
                        "\nPontos de Vida Recupera: " + selectedItem.getPontosVidaRecupera() +
                        "\nPontos de Ataque Extra: " + selectedItem.getPontosAtaqueExtra() +
                        "\nPontos de Defesa Extra: " + selectedItem.getPontosDefesaExtra() +
                        "\nPontos de Magia Extra: " + selectedItem.getPontosMagiaExtra());
            }
        });

        JScrollPane listScrollPane = new JScrollPane(itemList);

        itemDescriptionArea = new JTextArea();
        itemDescriptionArea.setEditable(false);
        JScrollPane descriptionScrollPane = new JScrollPane(itemDescriptionArea);

        JButton addButton = new JButton("Adicionar Item");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = JOptionPane.showInputDialog("Nome do Item:");
                String descricao = JOptionPane.showInputDialog("Descrição do Item:");
                int pontosVidaRecupera = Integer.parseInt(JOptionPane.showInputDialog("Pontos de Vida Recupera:"));
                int pontosAtaqueExtra = Integer.parseInt(JOptionPane.showInputDialog("Pontos de Ataque Extra:"));
                int pontosDefesaExtra = Integer.parseInt(JOptionPane.showInputDialog("Pontos de Defesa Extra:"));
                int pontosMagiaExtra = Integer.parseInt(JOptionPane.showInputDialog("Pontos de Magia Extra:"));
                if (nome != null && descricao != null) {
                    Item newItem = new Item(nome, descricao, pontosVidaRecupera, pontosAtaqueExtra, pontosDefesaExtra, pontosMagiaExtra);
                    inventario.adicionarItem(newItem);
                    listModel.addElement(newItem);
                }
            }
        });

        JButton removeButton = new JButton("Remover Item");
        removeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Item selectedItem = itemList.getSelectedValue();
                if (selectedItem != null) {
                    inventario.removerItem(selectedItem);
                    listModel.removeElement(selectedItem);
                }
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);

        setLayout(new BorderLayout());
        add(listScrollPane, BorderLayout.CENTER);
        add(descriptionScrollPane, BorderLayout.SOUTH);
        add(buttonPanel, BorderLayout.NORTH);
    }

    public static void acessarInventario() {
        SwingUtilities.invokeLater(() -> {
            InventarioWindow window = new InventarioWindow();
            window.setVisible(true);
        });
    }
}
