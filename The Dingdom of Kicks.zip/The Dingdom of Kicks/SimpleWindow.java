import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

public class SimpleWindow extends JFrame implements Runnable {

    private JButton playButton;
    private JTextArea playTextArea;

    public SimpleWindow() {
        setTitle("The Kingdom of Dyks");
        setSize(1080, 720);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
    }

    private void initUI() {
        // Caminho para a imagem de fundo
        String imagePath = "CapaTheKingdomOfDyks.png"; // Certifique-se de que o caminho está correto

        // Cria o painel de fundo com a imagem
        BackgroundPanel backgroundPanel = new BackgroundPanel(imagePath);
        backgroundPanel.setLayout(new BorderLayout());

        playButton = new JButton("Iniciar");
        playTextArea = new JTextArea();

        // Adiciona um evento de clique ao botão
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playTextArea.append("Botão clicado!\n");
            }
        });

        // Adiciona os componentes ao painel de fundo
        backgroundPanel.add(playButton, BorderLayout.SOUTH);
        backgroundPanel.add(playTextArea, BorderLayout.CENTER);

        // Adiciona o painel de fundo à janela
        add(backgroundPanel);
    }


@Override
public void run() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'run'");
}
}  