public class Item {
    private String nome;
    private String descricao;
    private int pontosVidaRecupera;
    private int pontosAtaqueExtra;
    private int pontosDefesaExtra;
    private int pontosMagiaExtra;

    public Item(String nome, String descricao, int pontosVidaRecupera, int pontosAtaqueExtra,
                int pontosDefesaExtra, int pontosMagiaExtra) {
        this.nome = nome;
        this.descricao = descricao;
        this.pontosVidaRecupera = pontosVidaRecupera;
        this.pontosAtaqueExtra = pontosAtaqueExtra;
        this.pontosDefesaExtra = pontosDefesaExtra;
        this.pontosMagiaExtra = pontosMagiaExtra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }

    @Override
    public String toString() {
        return nome;
    }

    public int getPontosMagiaExtra() {
        return pontosMagiaExtra;
    }

    public void setPontosMagiaExtra(int pontosMagiaExtra) {
        this.pontosMagiaExtra = pontosMagiaExtra;
    }

    public int getPontosDefesaExtra() {
        return pontosDefesaExtra;
    }

    public void setPontosDefesaExtra(int pontosDefesaExtra) {
        this.pontosDefesaExtra = pontosDefesaExtra;
    }

    public int getPontosAtaqueExtra() {
        return pontosAtaqueExtra;
    }

    public void setPontosAtaqueExtra(int pontosAtaqueExtra) {
        this.pontosAtaqueExtra = pontosAtaqueExtra;
    }

    public int getPontosVidaRecupera() {
        return pontosVidaRecupera;
    }

    public void setPontosVidaRecupera(int pontosVidaRecupera) {
        this.pontosVidaRecupera = pontosVidaRecupera;
    }
}
