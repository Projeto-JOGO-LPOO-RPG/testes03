public class Fase01 extends FasesGeral{

    
}